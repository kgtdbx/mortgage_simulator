library(testthat)
library(ZillowR)

test_check("ZillowR")
