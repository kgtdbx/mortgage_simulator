## Test environments

* local Windows 10.0.10586 Build 10586, R version 3.2.3
* win-builder (devel and release)


## R CMD check results

0 errors | 0 warnings | 1 note

* NOTE: New submission


## Reverse dependencies

This is a new submission, so there are no reverse dependencies.
